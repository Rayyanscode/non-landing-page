import react from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button,Form,FormControl,Nav,NavDropdown,Navbar,Container,Row,Col,Carousel,Card,CardGroup } from 'react-bootstrap';
import './style.css';

function All() {
    return(
        <>

        {/* nav bar start */}

        <Navbar bg="yellow" className="two" expand="lg">
      <Container fluid>
     <Navbar.Brand href="#"><img src="https://z.nooncdn.com/s/app/com/noon/images/logos/noon-black-en.svg" alt="" /></Navbar.Brand>
    <Navbar.Toggle aria-controls="navbarScroll" />
    <Navbar.Collapse id="navbarScroll">
      <Nav
        className="me-auto my-2 my-lg-0"
        style={{ maxHeight: '100px' }}
        navbarScroll
      >
        <NavDropdown title="Link" style={{marginRight:10}} id="navbarScrollingDropdown">
          <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Another action</NavDropdown.Item>
          <NavDropdown.Divider />
          <NavDropdown.Item href="#action5">
            Something else here
          </NavDropdown.Item>
        </NavDropdown>

        <Form className="d-flex" style={{width:1200}}>
        <FormControl
          type="search"
          placeholder="Search"
          className="me-2"
          aria-label="Search"
        />
        <Button variant="outline">Sign</Button>
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSiAY_GUgx2TF2_XUlRuGGefgo39motb-Zefh5CLRWF_3a-_BmI5PWulBOKXcFWfosKjEA&usqp=CAU" height={40} alt="" />

      </Form>
      <Button style={{marginLeft:20}} variant="outline">cart</Button>
      <img src="https://www.vhv.rs/dpng/d/428-4287684_background-shopping-cart-transparent-transparent-background-shopping-cart.png" height={40} alt="" />       
      </Nav>
    </Navbar.Collapse>
  </Container>
</Navbar>

        {/* nav bar end */}

        {/* second nav bar start */}

        <Navbar bg="light" expand="lg">
  <Container fluid>
    {/* <Navbar.Brand href="#">Navbar scroll</Navbar.Brand> */}
    <Navbar.Toggle aria-controls="navbarScroll" />
    <Navbar.Collapse id="navbarScroll">
      <Nav
        className="me-auto my-2 my-lg-0"
        style={{ maxHeight: '100px' }}
        navbarScroll
      >
        <NavDropdown title="All Categories"  id="navbarScrollingDropdown">
          <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
          <NavDropdown.Item href="#action4">Another action</NavDropdown.Item>
          <NavDropdown.Divider />
          <NavDropdown.Item href="#action5">
            Something else here
          </NavDropdown.Item>
        </NavDropdown>
        <Nav.Link href="#" style={{marginLeft:100,color:'Black'}}>
          Electronics
        </Nav.Link>
        <Nav.Link href="#" style={{marginLeft:50,color:'Black'}}>
          Men
        </Nav.Link>
        <Nav.Link href="#" style={{marginLeft:50,color:'Black'}}>
          Women
        </Nav.Link>
        <Nav.Link href="#" style={{marginLeft:50,color:'Black'}}>
          Home
        </Nav.Link>
        <Nav.Link href="#" style={{marginLeft:50,color:'Black'}}>
          Sports
        </Nav.Link>
        <Nav.Link href="#" style={{marginLeft:50,color:'Black'}}>
          Toys
        </Nav.Link>
        <Nav.Link href="#" style={{marginLeft:50,color:'Black'}}>
          Baby
        </Nav.Link>
        <Nav.Link href="#" style={{marginLeft:50,color:'Black'}}>
          Beauty
        </Nav.Link>
        <Nav.Link href="#" style={{marginLeft:50,color:'Black'}}>
          Best Seller
        </Nav.Link>
      </Nav>
    </Navbar.Collapse>
  </Container>
</Navbar>


        {/* second nav bar end */}



        {/* next part start */}

       <div>
       <img style={{marginLeft:66}} width={1349} height={70} src="https://k.nooncdn.com/cms/pages/20220112/79d9d231cd9d141c1346971a9de6b41a/en_dk-toggle.gif" alt="" />
       </div>

<Container fluid>
  <Row>
    <Col style={{marginLeft:58}} >
    <Carousel>
  <Carousel.Item>
    <img width={700} height={200}
      className="d-block w-100"
      src="https://k.nooncdn.com/cms/pages/20220211/95a2509c8f89c23e9f2d5e180cd9be74/en_slider-02.jpg"
      alt="First slide"
    />
    <Carousel.Caption>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img width={700} height={200}
      className="d-block w-100"
      src="https://k.nooncdn.com/cms/pages/20220204/ea812d6659e71d3d1d5a8e565c03205d/en_dk_uae-hero.gif"
      alt="Second slide"
    />

    <Carousel.Caption>
      </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img width={700} height={200}
      className="d-block w-100"
      src="https://k.nooncdn.com/cms/pages/20211115/471f4da41bdecbbc8be3b4b3c5b3fe2c/en_dk_uae-slider-01.gif"
      alt="Third slide"
    />

    <Carousel.Caption>
    </Carousel.Caption>
  </Carousel.Item>
</Carousel>
    </Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20220107/0e973955c45f6d0e499d1e622c845af5/en_dk_uae-fash-01.gif" width={305} height={200} alt="" /> <img style={{marginLeft:-4}} src="https://k.nooncdn.com/cms/pages/20220107/0e973955c45f6d0e499d1e622c845af5/en_dk_uae-fash-02.gif" width={310} height={200} alt="" /></Col>
  </Row>
</Container>


<Container fluid style={{width:1370,marginTop:20}}>
  <Row>
    <Col><img src="https://k.nooncdn.com/cms/pages/20220105/c15fd2d8aedf85c0fb666e011f81fdb8/en_mb-category-01-clearance.png" width={120} height={120} alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20210919/3637a874c692f426bb677358168ef8f4/en_mb-category-10.png" width={120} height={120} alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20220203/fbe23e00599d2d196e3587db5bc48e05/en_mb_uae-valentine-01.png"  width={120} height={120}alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20220207/c54d34061204faffa5c6b8bd723b0ad0/en_uae-giftcards.png" width={120} height={120} alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20210906/ccc8583272ec729c1b4db070fef87c9c/en_mb-category-03.png"  width={120} height={120}alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20220203/27a0d5211c1caeff8b8e8b6bb5340c9e/en_mb-category-05.png"  width={120} height={120}alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20210525/5e6536ce873b58ccd0cb4baf01ade972/en_mb-category-14.png"  width={120} height={120}alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20211205/facb109f7445b0f993137ce467180ea2/en_mb-category-06.png"  width={120} height={120}alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20211017/b5703aecad66057192e6faf14e029dc2/en_mb-category-12.png"  width={120} height={120}alt="" /></Col>
    
  </Row>
</Container>


<div style={{marginTop:30,marginLeft:60}}>
<h4>Recommended for you</h4>
</div>



<CardGroup style={{width:1370,marginLeft:60}}>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1638891634/N50840187A_1.jpg" height={200} width={300} />
    <Card.Body>
      <Card.Title>Apple Iphone</Card.Title>
      <Card.Text>
        Apple iphone 13 pro max 256gb
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1633754977/N22732308A_1.jpg" height={200} width={300} />
    <Card.Body>
      <Card.Title>Apple Earpod</Card.Title>
      <Card.Text>
        Apple Earpod with charging case white.
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1633343872/N40633047A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Sony play station 5</Card.Title>
      <Card.Text>
        sony play station 5 console
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1638548368/N31981756A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>noon east 15-Bar</Card.Title>
      <Card.Text>
      noon east 15-Bar Espresso coffee
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1605814041/N41190004A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Xiaomi Mi True Wireless</Card.Title>
      <Card.Text>
      Xiaomi Mi True Wireless Earbuds Basic 2 Black.
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1635349986/N47729493A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Electric Dancing</Card.Title>
      <Card.Text>
      Electric Dancing plant cactus.
      </Card.Text>
    </Card.Body>
  </Card>
</CardGroup>



<div style={{marginTop:30,marginLeft:60,marginBottom:20}}>
<h4>Cartful of love</h4>
</div>


<CardGroup style={{width:1370,marginLeft:60}}>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220208/e82860bb52383905de19ec61e4bb63a4/en_mb_uae-vd-grocery-05.png" height={230} width={200} />
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220208/e82860bb52383905de19ec61e4bb63a4/en_mb_uae-vd-grocery-06.png" height={230} width={200} />
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220208/e82860bb52383905de19ec61e4bb63a4/en_mb_uae-vd-grocery-07.png" height={230} width={200}/>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220208/e82860bb52383905de19ec61e4bb63a4/en_mb_uae-vd-grocery-01.png" height={230} width={200}/>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220208/e82860bb52383905de19ec61e4bb63a4/en_mb_uae-vd-grocery-03.png" height={230} width={200}/>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220208/e82860bb52383905de19ec61e4bb63a4/en_mb_uae-vd-grocery-04.png" height={230} width={200}/>
  </Card>
</CardGroup>





<CardGroup style={{width:1370,marginLeft:60,marginTop:40}}>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1635144779/N51496837A_1.jpg" height={200} width={300} />
    <Card.Body>
      <Card.Title>Apple Earpod</Card.Title>
      <Card.Text>
        Best Apple Earpod
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1638891634/N50840187A_1.jpg" height={200} width={300} />
    <Card.Body>
      <Card.Title>Apple Iphone</Card.Title>
      <Card.Text>
        Apple Iphone With Best Price.
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1633519297/N51219502A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>smart watch i7 pro max.</Card.Title>
      <Card.Text>
        Best smart watch.
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1635188660/N43807483A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Face Mask</Card.Title>
      <Card.Text>
      Best Quality Face Mask.
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1605795506/N23772548A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Eye Drop Spray</Card.Title>
      <Card.Text>
      Eye drop spray with low price.
      </Card.Text>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1635188669/N45745374A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Samsung LED</Card.Title>
      <Card.Text>
      50 inch samsung led with best quality.
      </Card.Text>
    </Card.Body>
  </Card>
</CardGroup>


<div>
  <img style={{width:1370,marginLeft:60,marginTop:20}} src="https://k.nooncdn.com/cms/pages/20220216/e4fc08291d496c68c02627596efe57bd/en_uae_dk-strip-01.png" alt="" />
</div>


<div>
  <img style={{width:1370,marginLeft:58,marginTop:30}} src="https://k.nooncdn.com/cms/pages/20220107/5d7f1c7ee4b7dcd3346ad03daa9f37c4/en_dk_uae-title-01.png" alt="" />
</div>



<CardGroup style={{width:1370,marginLeft:60}}>
  <Card>
    <Card.Img  variant="top" src="https://k.nooncdn.com/cms/pages/20220214/c18112897a1463814942ee29e8ebac87/en_dk_uae-deals-01.png" height={230} width={200} />
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220214/c18112897a1463814942ee29e8ebac87/en_dk_uae-deals-02.png" height={230} width={200} />
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220214/c18112897a1463814942ee29e8ebac87/en_dk_uae-deals-03.png" height={230} width={200}/>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220214/c18112897a1463814942ee29e8ebac87/en_dk_uae-deals-04.png" height={230} width={200}/>
  </Card>
</CardGroup>




<div style={{marginTop:30,marginLeft:60}}>
<h4 style={{fontStyle:"italic"}}>clearence Deals</h4>
</div>



<CardGroup style={{width:1370,marginLeft:60,marginTop:20}}>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1637474136/N42772458A_1.jpg" height={200} width={300} />
    <Card.Body>
      <Card.Title>Noon East</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1635748093/N22547721A_5.jpg" height={200} width={300} />
    <Card.Body>
      <Card.Title>noon East bamboo</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1625494177/N11073341A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>loreal paris</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1644818958/N11822356A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Hand Pump</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1643393494/N43433471A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Head Phone</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1628757449/N28983871A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>7 piece of glass</Card.Title>
    </Card.Body>
  </Card>
</CardGroup>



<Container style={{marginTop:20,backgroundColor:"lightgrey"}}>
  <Row>
    <Col><img src="https://k.nooncdn.com/mon/1644835487851-ckzmkkx2j4quv4tr7ed0rtxq6.png" style={{marginLeft:-50}} width={500} height={180} alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20220210/888be75b7091136958be4736fb003570/en_dk_ksa-spot-silver-03.png" alt="" /></Col>
    <Col><img src="https://k.nooncdn.com/cms/pages/20220210/888be75b7091136958be4736fb003570/en_dk_uae-spot-silver-02.png" alt="" /></Col>
  </Row>
</Container>



<div>
  <img style={{marginTop:20,width:1375,marginLeft:60}} src="https://k.nooncdn.com/cms/pages/20211214/5605d574371f6ed668d2931b8dffc2e5/en_strip-mashreq-01.gif" alt="" />
</div>







<div style={{marginTop:30,marginLeft:60}}>
<h4 style={{fontStyle:"italic"}}>Health care Essential</h4>
</div>



<CardGroup style={{width:1370,marginLeft:60,marginTop:20}}>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1602517718/N13710215A_1.jpg" height={200} width={300} />
    <Card.Body>
      <Card.Title>Dettol pack of 3.</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1621485200/N39535094A_1.jpg" height={200} width={300} />
    <Card.Body>
      <Card.Title>Generic ulv</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1592221002/N38650144A_2.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Washable mask</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1609828878/N37433140A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Anti smoke face sheet</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1602171422/N36150731A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>disposible face mask</Card.Title>
    </Card.Body>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://z.nooncdn.com/products/tr:n-t_240/v1635761852/N22130653A_1.jpg" height={200} width={200} />
    <Card.Body>
      <Card.Title>Branded Cream</Card.Title>
    </Card.Body>
  </Card>
</CardGroup>




<div>
  <img style={{marginTop:20,width:1375,marginLeft:60}} src="https://k.nooncdn.com/cms/pages/20211018/ecde4ae8250d6cd07b29d4de4b106f61/en_strip-00.png" alt="" />
</div>





<div style={{textAlign:'center'}}>
  <h1>50-80% OFF ALL CATEGORIES</h1>
</div>


<CardGroup style={{width:1370,marginLeft:60,marginTop:20}}>
  <Card>
    <Card.Img   variant="top" src="https://k.nooncdn.com/cms/pages/20220107/4563906ef76fd1cac5278c7a05e589f1/en_mb_uae-cat-01.png" height={400} width={200} />
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220107/4563906ef76fd1cac5278c7a05e589f1/en_mb_uae-cat-02.png" height={400} width={200} />
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220107/4563906ef76fd1cac5278c7a05e589f1/en_mb_uae-cat-05.png" height={400} width={200}/>
  </Card>
  <Card>
    <Card.Img variant="top" src="https://k.nooncdn.com/cms/pages/20220107/4563906ef76fd1cac5278c7a05e589f1/en_mb_uae-cat-06.png" height={400} width={200}/>
  </Card>
</CardGroup>




















<br/>
<br/>
<br/>
<br/>

<br/>
<br/>
<br/>
<br/>







    {/* next part start */}





        </>
    )
    
}

export default All;
