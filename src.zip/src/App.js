import logo from './logo.svg';
import './App.css';
import All from './landing';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (

      <All/>
  );
}

export default App;
